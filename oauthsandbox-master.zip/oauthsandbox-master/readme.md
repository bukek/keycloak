Just a plain box here.
---
Centos7 | a few utils | PasswordAuthentication yes.

